function sayHello(person){
    return "Hello" + person;

}

var user = "teacher McGee";

document.getElementById('para').innerHTML = sayHello(user);